===========================
PropulsionBasic, Version 1.0.1
Made by Rim032, 8/18/21
===========================

--Program Notes--

Thanks for installing my program. This program does simple calculations relating to velocity, speed and momentum.
This was initially made for practice, I often make simple programs during my free time for practice but I sought to
release this to the public. Just in-case if anyone wants to use it.

--Notes--

I planned on making this look good visually using the GTK 3 library for C but
I haven't got the library to work with Codeblocks properly, so I am just using
the default console app GUI, sorry :(.

--Contact Info--

You may contact me on Steam if you have any bugs, issues or questions. PLEASE
leave a comment if your trying to contact me on steam about PropulsionBasic because
I do not accept random friend request's without a comment first, sorry.
===============================================================================

--|Build Versions|--

1.0.0 - 8/13/21 - Private Completion #1 - Program is made and completed
1.0.1 - 8/18/21 - Public Release #1 - Added stuff for public release
